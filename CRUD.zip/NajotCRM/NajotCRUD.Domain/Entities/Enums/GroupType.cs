﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NajotCRUD.Domain.Entities.Enums
{
    public enum GroupType
    {
        Standart = 50,
        Bootcamp = 100
    }
}
